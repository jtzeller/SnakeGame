package SnakePack;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;

import javax.swing.JPanel;

public class SnakePanel extends JPanel implements ActionListener
{
	int score; //score
	
	static final int height = 1200;
	static final int width = 1200;
	
	static final int cellSize = 25; //Dimensions of 'unit' like snake body part or apple (x*y)
	static final int cellNum = (width * height) / cellSize; //Number of cells in the grid
	
	final int x[] = new int[cellNum]; //Snake body X coordinates, max size of snake set to total amount of grid cells
	final int y[] = new int[cellNum]; //Snake body y coordinates
	int snakeBodyCells = 4; //Starting amount of snake body parts
	
	static final int speed = 100; //Game Speed, higher values make it slower
	
	
	
	
	int fX; //Apple's X coordinate
	int fY; // Apples Y coordinate
	char direction = 'R'; //Direction of snake movement, can be L, left / R, right / U, up / D, down
	boolean end = false; // Set to true at game start, false = game over
	Timer timer;
	Random random;
	
	SnakePanel() 
	{
		random = new Random();
		this.setPreferredSize(new Dimension	(width,height));
		this.setBackground(Color.BLACK);
		this.setFocusable(true);
		this.addKeyListener(new MyKeyAdapter());
		startGame();
	}
	
	public void paint(Graphics Gr)
	{
		super.paint(Gr);
		draw(Gr);
	}
	
	public void draw(Graphics Gr)
	{
		if(end)
		{
			for(int i = 0; i < (height/cellSize); i++)
			{
				Gr.drawLine(i * cellSize, 0, i * cellSize, height);
				Gr.drawLine(0, i * cellSize, width, i * cellSize);
			}
			
			Gr.setColor(Color.YELLOW);
			Gr.fillOval(fX, fY, cellSize, cellSize);
			
			for (int i = 0; i < snakeBodyCells; i++) 
			{
				if(i == 0)
				{
					Gr.setColor(Color.WHITE);
				}
				else
				{
					Gr.setColor(Color.BLUE);
				}
				Gr.fillOval(x[i], y[i], cellSize, cellSize);
			}
			Gr.setColor(Color.white);
			Gr.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 40));
			FontMetrics Met = getFontMetrics(Gr.getFont());
			Gr.drawString("Apples Eaten: " + score, (width - Met.stringWidth("Apples Eaten: " + score)) / 2, Gr.getFont().getSize());
		}
		else
		{
			gameOver(Gr);
		}
	}
	
	public void move()
	{
		for(int i = snakeBodyCells; i > 0; i--)
		{
			x[i] = x[i - 1];
			y[i] = y[i - 1];
		}
			
		switch(direction)
		{
			case 'U':
				y[0] = y[0] - cellSize;
				break;
			case 'D':
				y[0] = y[0] + cellSize;
				break;
			case 'L':
				x[0] = x[0] - cellSize;
				break;
			case 'R':
				x[0] = x[0] + cellSize;
				break;
		}
	}
	
	public void newApple()
	{
		fX = random.nextInt((int)(width / cellSize)) * cellSize;
		fY = random.nextInt((int)(height / cellSize)) * cellSize;
	}
	
	public void checkApple()
	{
		if((x[0] == fX) && (y[0] == fY))
		{
			snakeBodyCells++;
			score++;
			newApple();
		}
	}
	
	public void checkCollision()
	{
		for(int i = snakeBodyCells; i > 0; i--)
		{
			if((x[0] == x[i]) && (y[0] == y[i]))
			{
				end = false;
			}
		}
		if(x[0] < 0)
		{
			end = false;
		}
		if(x[0] > width)
		{
			end = false;
		}
		if(y[0] < 0)
		{
			end = false;
		}
		if(y[0] > height)
		{
			end = false;
		}
		if(!end)
		{
			timer.stop();
		}
	}
	
	public void startGame()
	{
		newApple();
		end = true;
		timer = new Timer(speed,this);
		timer.start();
	}
	
	public void gameOver(Graphics Gr)
	{
		Gr.setColor(Color.YELLOW);
		Gr.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 40));
		FontMetrics Met1 = getFontMetrics(Gr.getFont());
		Gr.drawString("Apples Eaten: " + score, (width - Met1.stringWidth("Apples Eaten: " + score)) / 2, Gr.getFont().getSize());
		
		Gr.setColor(Color.WHITE);
		Gr.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 75));
		FontMetrics Met2 = getFontMetrics(Gr.getFont());
		Gr.drawString("Game Over :(", (width - Met2.stringWidth("Game Over :(")) / 2, height / 2);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(end)
		{
			move();
			checkApple();
			checkCollision();
		}
		repaint();
	}
	
	public class MyKeyAdapter extends KeyAdapter
	{
		@Override
		public void keyPressed(KeyEvent Ev)
		{
			switch(Ev.getKeyCode())
			{
				case KeyEvent.VK_A:
				{
					if(direction != 'R')
					{
						direction = 'L';
					}
					break;
				}
				case KeyEvent.VK_D:
				{
					if(direction != 'L')
					{
						direction = 'R';
					}
					break;
				}
				case KeyEvent.VK_W:
				{
					if(direction != 'D')
					{
						direction = 'U';
					}
					break;
				}
				case KeyEvent.VK_S:
				{
					if(direction != 'U')
					{
						direction = 'D';
					}
					break;
				}
			}
		}
	}

}
