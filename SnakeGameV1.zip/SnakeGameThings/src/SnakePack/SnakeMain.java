package SnakePack;

public class SnakeMain 
{
	public static void main(String[] args)
	{
		SnakeFrame SF = new SnakeFrame();
	}

}
