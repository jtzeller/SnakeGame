package SnakePack;

import javax.swing.JFrame;

public class SnakeFrame extends JFrame
{
	SnakeFrame()
	{
		SnakePanel SP = new SnakePanel();
		this.add(SP);
		this.setTitle("SnakeGameV1.1.1");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.pack();
		this.setVisible(true);
		this.setLocationRelativeTo(null);
	}
}
