package application;

import java.io.IOException;
import application.Main.GameMode;
import application.Main.GameType;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Controller
{
	private Stage stage;
	private Scene scene;
	private Parent root;
	
	public void PlayMenu(ActionEvent e)
	{
		System.out.println("Play Menu");
		try 
		{
			root = FXMLLoader.load(getClass().getResource("PlayMenu.fxml"));
			stage = (Stage)((Node)e.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
			Main.GM = GameMode.SINGLEPLAYER;
			Main.GT = GameType.TARGETSCORE;
			Main.TargetScore = 15;
			Main.speed = 5;
			Main.DefaultSpeed = 5;
			Main.GameSpeedIncreases = true;
		} 
		catch (IOException e1) 
		{
			e1.printStackTrace();
		}
	}
	
	public void SetSinglePlayer(ActionEvent e)
	{
		Main.GM = GameMode.SINGLEPLAYER;
		System.out.println("Game Mode = Singleplayer");
	}
	public void SetCoop(ActionEvent e)
	{
		Main.GM = GameMode.COOP;
		System.out.println("Game Mode = Coop");
	}
	public void SetTargetScore(ActionEvent e)
	{
		Main.GT = GameType.TARGETSCORE;

		System.out.println("Game Type = Target Score");
	}
	public void SetEndless(ActionEvent e)
	{
		Main.GT = GameType.ENDLESS;
		System.out.println("Game Type = Endless");
	}
	
	
	
	
	public void setGameSpeedIncreasesON(ActionEvent e)
	{
		Main.GameSpeedIncreases = true;
	}
	public void setGameSpeedIncreasesOFF(ActionEvent e)
	{
		Main.GameSpeedIncreases = false;
	}
	
	
	
	
	
	
	public void setDifftoVeryEasy(ActionEvent e)
	{
		Main.TargetScore = 15;
		Main.speed = 5;
		Main.DefaultSpeed = Main.speed;
		System.out.println("Set Diff Very Easy");
	}
	
	public void setDifftoEasy(ActionEvent e)
	{
		Main.TargetScore = 20;
		Main.speed = 10;
		Main.DefaultSpeed = Main.speed;
		System.out.println("Set Diff Easy");
	}
	
	public void setDifftoMedium(ActionEvent e)
	{
		Main.TargetScore = 30;
		Main.speed = 15;
		Main.DefaultSpeed = Main.speed;
		System.out.println("Set Diff Medium");
	}
	
	public void setDifftoHard(ActionEvent e)
	{
		Main.TargetScore = 40;
		Main.speed = 20;
		Main.DefaultSpeed = Main.speed;
		System.out.println("Set Diff Hard");
	}
	
	public void setDifftoVeryHard(ActionEvent e)
	{
		Main.TargetScore = 50;
		Main.speed = 25;
		Main.DefaultSpeed = Main.speed;
		System.out.println("Set Diff Very Hard");
	}
	
	public void setDifftoImpossible(ActionEvent e)
	{
		Main.TargetScore = 75;
		Main.speed = 30;
		Main.DefaultSpeed = Main.speed;
		System.out.println("Set Diff Impossible");
	}
	
	
	
	
	
	
	
	public void returnToMain(ActionEvent e)
	{
		System.out.println("Main Menu");
		try 
		{
			root = FXMLLoader.load(getClass().getResource("Main.fxml"));
			stage = (Stage)((Node)e.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} 
		catch (IOException e1) 
		{
			e1.printStackTrace();
		}
	}
	
	public void returnToMain(Stage e)
	{
		System.out.println("Main Menu");
		try 
		{
			root = FXMLLoader.load(getClass().getResource("Main.fxml"));
			stage = e;
			scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} 
		catch (IOException e1) 
		{
			e1.printStackTrace();
		}
	}

	public void Play(ActionEvent e)
	{
		System.out.println("Play Singleplayer Target Score");
		stage = (Stage)((Node)e.getSource()).getScene().getWindow();
		Main.startGame(stage);
	}
	
	public void Exit(ActionEvent e)
	{
		System.out.println("Exiting Program");
		stage = (Stage)((Node)e.getSource()).getScene().getWindow();
		stage.close();
	}
}
