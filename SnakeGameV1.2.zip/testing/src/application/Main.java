package application;
	
import java.util.ArrayList;
import java.util.List;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class Main extends Application 
{
	static GameMode GM;
	static GameType GT;
	static boolean TargetReached = false;
	static boolean end = false;
	static boolean paused = false;
	static boolean playerTwoWins = false;
	
	static boolean movedOnTick = false;
	static boolean SecondMovedOnTick = false;
	
	static boolean GameSpeedIncreases = false;
	static GraphicsContext GraphCon;
	static AnimTime AT;
	static int width = 30;
	static int height = 30;
	
	static int score = 0;
	static int secondScore = 0;
	
	static int TargetScore = 100;
	static Text Score = new Text("");
	static Text SecondScore = new Text("");
	
	static int speed = 10;
	
	static int DefaultSpeed;
	static int fX = 0;
	static int fY = 0;
	static int cellSize = 25;
	
	static List<body> snakeBody = new ArrayList<>();
	static List<body> SecondsnakeBody = new ArrayList<>();
	
	static D direction = D.LEFT;
	static D SecondDirection = D.RIGHT;
	
	public enum D
	{
		LEFT, RIGHT, UP, DOWN
	}
	
	public enum GameMode
	{
		SINGLEPLAYER, COOP
	}
	
	public enum GameType
	{
		TARGETSCORE, ENDLESS
	}
	
	public static class body
	{
		int x;
		int y;
		public body(int x, int y)
		{
			this.x = x;
			this.y = y;
		}
	}
	
	public void start(Stage primaryStage) 
	{
		try
		{
			Parent root = FXMLLoader.load(getClass().getResource("Main.fxml"));
			Scene scene = new Scene(root);
			primaryStage.setScene(scene);
			primaryStage.setTitle("Snake V1.1.1");
			Image icon = new Image("SnakeIcon.png");
			primaryStage.setResizable(false);
			primaryStage.getIcons().add(icon);
			primaryStage.show();	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void startGame(Stage primaryStage) 
	{
		try
		{
			
			paused = false;
			findValidNewFoodSpawnLocation();
			VBox root = new VBox();
			if(GT.equals(GameType.TARGETSCORE))
			{
				Score = new Text("Score: " + score + " ||  Target: " + TargetScore);
			}
			else
			{
				Score = new Text("Score: " + score);
			}
			Canvas C = new Canvas(width * cellSize, height * cellSize);
			GraphicsContext gc = C.getGraphicsContext2D();
			GraphCon = gc;
			Text Help = new Text("'M' to Exit to Main Menu || 'Q' to Exit to Desktop || 'Esc' to Pause || 'R' to Restart");
			Help.setTextAlignment(TextAlignment.CENTER);
			root.setAlignment(Pos.TOP_CENTER);
			root.getChildren().add(Score);
			root.getChildren().add(C);
			root.getChildren().add(Help);
			
			StartTimer(gc);
			
			Scene scene = new Scene(root);
			
			handleInput(scene, primaryStage);
			
			snakeBody.add(new body((width / 2) + 5, (height / 2) + 5));
		    snakeBody.add(new body((width / 2) + 5, (height / 2) + 5));
		    snakeBody.add(new body((width / 2) + 5, (height / 2) + 5));
			if(GM == GM.COOP)
			{
			    SecondsnakeBody.add(new body((width / 2) - 5, (height / 2) - 5));
			    SecondsnakeBody.add(new body((width / 2) - 5, (height / 2) - 5));
			    SecondsnakeBody.add(new body((width / 2) - 5, (height / 2) - 5));
			}
			restartGame();
			
			primaryStage.setScene(scene);
			primaryStage.setTitle("Snake V1.1.1");
			Image icon = new Image("SnakeIcon.png");
			primaryStage.setResizable(false);
			primaryStage.getIcons().add(icon);
			primaryStage.show();	
			System.out.println(javafx.scene.text.Font.getFamilies());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void StartTimer(GraphicsContext gc)
	{
		AT = new AnimTime();
		AT.start();
	}
	
	public static class AnimTime extends AnimationTimer
	{
		long lastTick = 0;
		
		@Override
		public void handle(long now) 
		{
			if(lastTick == 0)
			{
				lastTick = now;
				update(GraphCon);
				return;
			}
			if(now - lastTick > 1000000000 / speed)
			{
				lastTick = now;
				update(GraphCon);
			}
		}
	}
	
	public static void handleInput(Scene scene, Stage s)
	{
		scene.addEventFilter(KeyEvent.KEY_PRESSED, key -> {
			if(key.getCode() == KeyCode.W && direction != D.DOWN && !movedOnTick)
			{
				movedOnTick = true;
				direction = D.UP;
			}
			if(key.getCode() == KeyCode.S && direction != D.UP && !movedOnTick)
			{
				movedOnTick = true;
				direction = D.DOWN;
			}
			if(key.getCode() == KeyCode.A && direction != D.RIGHT && !movedOnTick)
			{
				movedOnTick = true;
				direction = D.LEFT;
			}
			if(key.getCode() == KeyCode.D && direction != D.LEFT && !movedOnTick)
			{
				movedOnTick = true;
				direction = D.RIGHT;
			}
			
			
			
			
			
			if(key.getCode() == KeyCode.I && SecondDirection != D.DOWN && !SecondMovedOnTick)
			{
				SecondMovedOnTick = true;
				SecondDirection = D.UP;
			}
			if(key.getCode() == KeyCode.K && SecondDirection != D.UP && !SecondMovedOnTick)
			{
				SecondMovedOnTick = true;
				SecondDirection = D.DOWN;
			}
			if(key.getCode() == KeyCode.J && SecondDirection != D.RIGHT && !SecondMovedOnTick)
			{
				SecondMovedOnTick = true;
				SecondDirection = D.LEFT;
			}
			if(key.getCode() == KeyCode.L && SecondDirection != D.LEFT && !SecondMovedOnTick)
			{
				SecondMovedOnTick = true;
				SecondDirection = D.RIGHT;
			}
			
			
			
			
			
			
			if(key.getCode() == KeyCode.R)
			{
				restartGame();
			}
			if(key.getCode() == KeyCode.ESCAPE)
			{
				pauseGame();
			}
			if(key.getCode() == KeyCode.M)
			{
				application.Controller con = new application.Controller();
				paused = true;
				AT.stop();
				con.returnToMain(s);
			}
		});
	}
	
	public static void pauseGame()
	{
		if(paused)
		{
			paused = false;
		}
		else
		{
			paused = true;	
		}
	}
	
	public static void update(GraphicsContext gc)
	{
		//check if game is over
		if(end)
		{
			//check if single player
			if(GM == GameMode.SINGLEPLAYER)
			{
				//check if game mode is target score
				if(GT == GameType.TARGETSCORE)
				{
					//check if target score was reached
					if(TargetReached)
					{
						gc.setTextAlign(TextAlignment.CENTER);
						gc.setTextBaseline(VPos.CENTER);
						gc.setFont(new Font("HP Simplified Jpan", 70));
						gc.setFill(javafx.scene.paint.Color.RED);
						gc.fillText("Target Score Reached", gc.getCanvas().getWidth()/2, gc.getCanvas().getHeight()/2);
						gc.setStroke(javafx.scene.paint.Color.WHITE);
					    gc.setLineWidth(2);
				        gc.strokeText("Target Score Reached", gc.getCanvas().getWidth()/2, gc.getCanvas().getHeight()/2);
					}
					//target score was not reached
					else
					{
						gc.setTextAlign(TextAlignment.CENTER);
						gc.setTextBaseline(VPos.CENTER);
						gc.setFont(new Font("HP Simplified Jpan", 50));
						gc.setFill(javafx.scene.paint.Color.RED);
						gc.fillText((TargetScore - score) + " Points From Target Score", gc.getCanvas().getWidth()/2, gc.getCanvas().getHeight()/2);
						gc.setStroke(javafx.scene.paint.Color.WHITE);
					    gc.setLineWidth(2);
				        gc.strokeText((TargetScore - score) + " Points From Target Score", gc.getCanvas().getWidth()/2, gc.getCanvas().getHeight()/2);
					}
				}
				//game mode is endless
				else
				{
					gc.setTextAlign(TextAlignment.CENTER);
					gc.setTextBaseline(VPos.CENTER);
					gc.setFont(new Font("HP Simplified Jpan", 90));
					gc.setFill(javafx.scene.paint.Color.RED);
					gc.fillText("Game Over", gc.getCanvas().getWidth()/2, gc.getCanvas().getHeight()/2);
					gc.setStroke(javafx.scene.paint.Color.WHITE);
				    gc.setLineWidth(2);
			        gc.strokeText("Game Over", gc.getCanvas().getWidth()/2, gc.getCanvas().getHeight()/2);
				}
			}
			//coop
			else
			{
				if(playerTwoWins)
				{
					gc.setTextAlign(TextAlignment.CENTER);
					gc.setTextBaseline(VPos.CENTER);
					gc.setFont(new Font("HP Simplified Jpan", 90));
					gc.setFill(javafx.scene.paint.Color.RED);
					gc.fillText("Player Two Wins", gc.getCanvas().getWidth()/2, gc.getCanvas().getHeight()/2);
					gc.setStroke(javafx.scene.paint.Color.WHITE);
				    gc.setLineWidth(2);
			        gc.strokeText("Player Two Wins", gc.getCanvas().getWidth()/2, gc.getCanvas().getHeight()/2);
				}
				else
				{
					gc.setTextAlign(TextAlignment.CENTER);
					gc.setTextBaseline(VPos.CENTER);
					gc.setFont(new Font("HP Simplified Jpan", 90));
					gc.setFill(javafx.scene.paint.Color.RED);
					gc.fillText("Player One Wins", gc.getCanvas().getWidth()/2, gc.getCanvas().getHeight()/2);
					gc.setStroke(javafx.scene.paint.Color.WHITE);
				    gc.setLineWidth(2);
			        gc.strokeText("Player One Wins", gc.getCanvas().getWidth()/2, gc.getCanvas().getHeight()/2);
				}
			}
			return;
		}
		if(!paused)
		{
			if(score == TargetScore && GT == GT.TARGETSCORE)
			{
				TargetReached = true;
				end = true;
			}
			if(secondScore == TargetScore && GT == GT.TARGETSCORE)
			{
				playerTwoWins = true;
				TargetReached = true;
				end = true;
			}
			if(GM == GM.COOP)
			{
				if(GT.equals(GameType.TARGETSCORE))
				{
					Score.setText("Player One Score: " + score + " ||  Target: " + TargetScore + " || Player Two Score: " + secondScore);
				}
				else
				{
					Score.setText("Player One Score: " + score + " || Player Two Score: " + secondScore);
				}
			}
			else
			{
				if(GT.equals(GameType.TARGETSCORE))
				{
					Score.setText("Score: " + score + " ||  Target: " + TargetScore);
				}
				else
				{
					Score.setText("Score: " + score);
				}
			}
			
			updateSnakeBodyLocation();
			checkCollisions();
			remakeGrid(gc);
			drawStuff(gc);
		}
		
	}	
	
	public static void drawStuff(GraphicsContext gc)
	{
		gc.setFill(javafx.scene.paint.Color.WHITE);
		gc.setFont(new Font("", 30));
		gc.setFill(javafx.scene.paint.Color.WHITE);
		gc.fillOval(fX * cellSize, fY * cellSize, cellSize, cellSize);
		gc.setStroke(javafx.scene.paint.Color.MEDIUMPURPLE);
		gc.strokeOval(fX * cellSize, fY * cellSize, cellSize, cellSize);
		for(int i = 0; i < snakeBody.size(); i++)
		{
			body sbp = snakeBody.get(i);
			if(i == 0)
			{
				gc.setFill(javafx.scene.paint.Color.YELLOW);
				gc.fillRoundRect(sbp.x * cellSize, sbp.y * cellSize, cellSize - 1, cellSize - 1, 10, 10);
				gc.setStroke(javafx.scene.paint.Color.BLUE);
				gc.strokeRoundRect(sbp.x * cellSize, sbp.y * cellSize, cellSize - 1, cellSize - 1, 10, 10);
			}
			else
			{
				gc.setFill(javafx.scene.paint.Color.BLUE);
				gc.fillRoundRect(sbp.x * cellSize, sbp.y * cellSize, cellSize - 1, cellSize - 1, 10, 10);
				gc.setStroke(javafx.scene.paint.Color.YELLOW);
				gc.strokeRoundRect(sbp.x * cellSize, sbp.y * cellSize, cellSize - 1, cellSize - 1, 10, 10);
			}
		}
		if(GM == GM.COOP)
		{
			for(int i = 0; i < SecondsnakeBody.size(); i++)
			{
				body sbp = SecondsnakeBody.get(i);
				if(i == 0)
				{
					gc.setFill(javafx.scene.paint.Color.RED);
					gc.fillRoundRect(sbp.x * cellSize, sbp.y * cellSize, cellSize - 1, cellSize - 1, 10, 10);
					gc.setStroke(javafx.scene.paint.Color.LIGHTGREEN);
					gc.strokeRoundRect(sbp.x * cellSize, sbp.y * cellSize, cellSize - 1, cellSize - 1, 10, 10);
				}
				else
				{
					gc.setFill(javafx.scene.paint.Color.LIGHTGREEN);
					gc.fillRoundRect(sbp.x * cellSize, sbp.y * cellSize, cellSize - 1, cellSize - 1, 10, 10);
					gc.setStroke(javafx.scene.paint.Color.RED);
					gc.strokeRoundRect(sbp.x * cellSize, sbp.y * cellSize, cellSize - 1, cellSize - 1, 10, 10);
				}
			}
		}
	}
	
	public static void remakeGrid(GraphicsContext gc)
	{
		for (int i = 0; i < width; i++) 
		{
		    for (int j = 0; j < height; j++) 
		    {
		        boolean alt = (i % 2 == 0 && j % 2 == 0) || (i % 2 == 1 && j % 2 == 1);
		        gc.setFill(alt ? javafx.scene.paint.Color.GREY : javafx.scene.paint.Color.DARKGREY);
		        gc.fillRect(i * cellSize, j * cellSize, cellSize, cellSize);
		    }
		}
	}
	
	public static void checkCollisions()
	{
		///Check if player 1 head is on food
		if(fX == snakeBody.get(0).x && fY == snakeBody.get(0).y)
		{
			snakeBody.add(new body(-1,-1));
			score++;
			if(GameSpeedIncreases)
			{
				speed++;
			}
			findValidNewFoodSpawnLocation();
		}
		
		
		
		
		if(GM == GM.COOP)
		{
			///check if second player head is on food
			if(fX == SecondsnakeBody.get(0).x && fY == SecondsnakeBody.get(0).y)
			{
				SecondsnakeBody.add(new body(-1,-1));
				secondScore++;
				if(GameSpeedIncreases)
				{
					speed++;
				}
				findValidNewFoodSpawnLocation();
			}
			
			//check if player 2 is colliding with player 1 body
			for (int i = 0; i < snakeBody.size(); i++) 
			{
				if(SecondsnakeBody.get(0).x == snakeBody.get(i).x && SecondsnakeBody.get(0).y == snakeBody.get(i).y)
				{
					end = true;
				}
			}
			
			
			//check if player 1 is colliding with player 2 body
			for (int i = 0; i < SecondsnakeBody.size(); i++) 
			{
				if(snakeBody.get(0).x == SecondsnakeBody.get(i).x && snakeBody.get(0).y == SecondsnakeBody.get(i).y)
				{
					playerTwoWins = true;
					end = true;
				}
			}
		}
		
		
		//check if player 1 is colliding with self
		for(int i = 1; i < snakeBody.size(); i++)
		{
			if(snakeBody.get(0).x == snakeBody.get(i).x && snakeBody.get(0).y == snakeBody.get(i).y)
			{
				playerTwoWins = true;
				end = true;
			}
		}
		if(GM == GM.COOP)
		{
			//check if player 2 is colliding with self
			for(int i = 1; i < SecondsnakeBody.size(); i++)
			{
				if(SecondsnakeBody.get(0).x == SecondsnakeBody.get(i).x && SecondsnakeBody.get(0).y == SecondsnakeBody.get(i).y)
				{
					end = true;
				}
			}
		}
	}
	
	public static void updateSnakeBodyLocation()
	{
		for(int i = snakeBody.size() - 1; i >= 1; i--)
		{
			snakeBody.get(i).x = snakeBody.get(i-1).x;
			snakeBody.get(i).y = snakeBody.get(i-1).y;
		}
		switch(direction)
		{
		case UP:
			snakeBody.get(0).y--;
			if(snakeBody.get(0).y < 0)
			{
				playerTwoWins = true;
				end = true;
			}
			break;
		case DOWN:
			snakeBody.get(0).y++;
			if(snakeBody.get(0).y > height - 1)
			{
				playerTwoWins = true;
				end = true;
			}
			break;
		case LEFT:
			snakeBody.get(0).x--;
			if(snakeBody.get(0).x < 0)
			{
				playerTwoWins = true;
				end = true;
			}
			break;
		case RIGHT:
			snakeBody.get(0).x++;
			if(snakeBody.get(0).x > width - 1)
			{
				playerTwoWins = true;
				end = true;
			}
			break;
		}
		
		if(GM == GM.COOP)
		{
			for(int i = SecondsnakeBody.size() - 1; i >= 1; i--)
			{
				SecondsnakeBody.get(i).x = SecondsnakeBody.get(i-1).x;
				SecondsnakeBody.get(i).y = SecondsnakeBody.get(i-1).y;
			}
			switch(SecondDirection)
			{
			case UP:
				SecondsnakeBody.get(0).y--;
				if(SecondsnakeBody.get(0).y < 0)
				{
					end = true;
				}
				break;
			case DOWN:
				SecondsnakeBody.get(0).y++;
				if(SecondsnakeBody.get(0).y > height - 1)
				{
					end = true;
				}
				break;
			case LEFT:
				SecondsnakeBody.get(0).x--;
				if(SecondsnakeBody.get(0).x < 0)
				{
					end = true;
				}
				break;
			case RIGHT:
				SecondsnakeBody.get(0).x++;
				if(SecondsnakeBody.get(0).x > width - 1)
				{
					end = true;
				}
				break;
			}
		}
		
		
		
		
		movedOnTick = false;
		SecondMovedOnTick = false;
	}

	public static void findValidNewFoodSpawnLocation()
	{
		boolean validLocation = true;
		while(true)
		{
			fX = (int) (Math.random() * width);
			fY = (int) (Math.random() * height);
			for(body sbc: snakeBody)
			{
				if(sbc.x == fX && sbc.y == fY)
				{
					validLocation = false;
				}
			}
			for(body sbc: SecondsnakeBody)
			{
				if(sbc.x == fX && sbc.y == fY)
				{
					validLocation = false;
				}
			}
			if(validLocation == true)
			{
				break;
			}
			else
			{
				validLocation = true;
			}
		}
	}
	
	public static void restartGame() 
	{
		System.out.println("Restarting Game...");
	    end = false;
	    playerTwoWins = false;
	    direction = D.LEFT;
	    snakeBody.clear();
	    snakeBody.add(new body((width / 2) + 5, (height / 2) + 5));
	    snakeBody.add(new body((width / 2) + 5, (height / 2) + 5));
	    snakeBody.add(new body((width / 2) + 5, (height / 2) + 5));
	    if(GM == GM.COOP)
	    {
	    	SecondDirection = D.RIGHT;
		    SecondsnakeBody.clear();
		    SecondsnakeBody.add(new body((width / 2) - 5, (height / 2) - 5));
		    SecondsnakeBody.add(new body((width / 2) - 5, (height / 2) - 5));
		    SecondsnakeBody.add(new body((width / 2) - 5, (height / 2) - 5));
	    }
	    findValidNewFoodSpawnLocation();
	    score = 0;
	    secondScore = 0;
	    speed = DefaultSpeed;
	}
	
	public static void main(String[] args) 
	{
		launch(args);
	}
}